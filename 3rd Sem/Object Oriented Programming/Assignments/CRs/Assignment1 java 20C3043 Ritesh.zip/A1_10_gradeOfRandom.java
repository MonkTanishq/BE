import java.util.Random;
public class A1_10_gradeOfRandom{
    public static void main(String[] args) {
        Random run=new Random();
        int a= run.nextInt(60,99);
        System.out.println("Number is: "+a);
        System.out.print("It's grade is: ");
        if(a>=60 && a<65){
            System.out.println("C-");
        }
        else if(a>=65 && a<70){
            System.out.println("C");
        }
        else if(a>=70 && a<74){
            System.out.println("C+");
        }
        else if(a>=74 && a<78){
            System.out.println("B-");
        }
        else if(a>=78 && a<83){
            System.out.println("B");
        }
        else if(a>=83 && a<87){
            System.out.println("B+");
        }
        else if(a>=87 && a<91){
            System.out.println("A-");
        }
        else if(a>=91 && a<95){
            System.out.println("A");
        }
        else{
            System.out.println("A+");
        }
    }
}
