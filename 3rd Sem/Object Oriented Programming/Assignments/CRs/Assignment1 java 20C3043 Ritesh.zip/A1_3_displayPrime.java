public class A1_3_displayPrime{
    public static void main(String[] args) {
        System.out.println("Prime number between 1 to 200 is: ");
        for(int i=1;i<=200;i++){
            int p=0;
            for(int j=i;j>=1;j--){
                if(i%j==0){
                    p++;
                }
            }
            if(p==2){
                System.out.print(i+" ");
            }
        }
    }
}
