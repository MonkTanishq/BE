public class A1_4_sumOfInteger{
    public static void main(String[] args) {
        //sum of integer grater than 100 and less than 200 which is divisible by 7
        int sum=0;
        for(int i=100;i<=200;i++){
            if(i%7==0){
                sum=sum+i;
            }
        }
        System.out.print("sum of integer is:"+sum);
    }
}
