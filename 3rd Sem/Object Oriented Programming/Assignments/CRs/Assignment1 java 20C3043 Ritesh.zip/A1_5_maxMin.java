public class A1_5_maxMin{
    public static void main(String[] args) {
        int a=8;
        int b=5;
        if(a<b){
            System.out.println("Max is:"+b);
            System.out.println("Min is:"+a);
        }
        else{
            System.out.println("Max is:"+a);
            System.out.println("Min is:"+b);
        }
    }
}
