class circle{
    double radius;
    double angle;
    public double circumCircle(){
        return 6.28*radius;
    }
    public double arcLength(){
        return angle*radius;
    }
}
public class A1_6_circleParameter{
    public static void main(String[] args) {
        circle data = new circle();
        data.radius=10;
        data.angle=45;
        System.out.println("circumference of circle is: "+ data.circumCircle());
        System.out.println("arc length of circle is: "+data.arcLength());
    }
}
