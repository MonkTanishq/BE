class polygons{
    int side;      //side length of n sided polygon
    int height;    //perpendicular distance of side from center of polygon
    int n;         //number of side in polygon
    public float getArea(){
        return side*height*n;
    }
    public float getParameter(){
        return n*side;
    }
}
public class A1_7_polygons{
    public static void main(String[] args) {
        polygons data= new polygons();
        data.side=7;
        data.height=5;
        data.n=9;
        System.out.println("Area is: "+data.getArea()/2);
        System.out.println("Parameter is: " +data.getParameter());
    }
}
