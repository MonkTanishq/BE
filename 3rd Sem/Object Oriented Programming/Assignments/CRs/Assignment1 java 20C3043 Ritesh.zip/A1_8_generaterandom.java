import java.util.Random;

public class A1_8_generaterandom{
    public static void main(String[] args) {
        Random obj=new Random();
        System.out.println("Random number between 1 to 100");
        for(int i=1;i<=5;i++){
            System.out.println(obj.nextInt(1,100));
        }
    }
}
