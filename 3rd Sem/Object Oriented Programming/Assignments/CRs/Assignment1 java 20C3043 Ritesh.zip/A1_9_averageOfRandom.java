import java.util.Random;
public class A1_9_averageOfRandom{
    public static void main(String[] args) {
        int sum=0;
        Random run =new Random();
        System.out.println("Random numbers are");
        for(int i=1;i<=8;i++){
            int a=run.nextInt();
            System.out.println(a);
            sum=sum+a;
        }
        System.out.println("Average of this random number is: "+ sum/8);
    }
}
