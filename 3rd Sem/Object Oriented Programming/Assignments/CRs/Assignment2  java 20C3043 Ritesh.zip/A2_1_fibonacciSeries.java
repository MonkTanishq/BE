public class A2_1_fibonacciSeries{
    public static void main(String[] args) {
        int first=0;
        int second=1;
        int third,n=9;
        System.out.print("0 1 ");
        for(int i=1;i<=n;i++){
            third=first+second;
            System.out.print(third +" ");
            first=second;
            second=third;
        }
    }
}
