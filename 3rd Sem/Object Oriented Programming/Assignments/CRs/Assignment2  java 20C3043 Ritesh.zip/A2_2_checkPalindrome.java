public class A2_2_checkPalindrome{
    public static void main(String[] args) {
        int n=1234321;
        int p=n;
        int rev=0;
        while (n != 0) {
            int a=n%10;
            rev=rev*10+a;
            n=n/10;
        }
        if(rev==p){
            System.out.println("Number is palindrome");
        }
        else{
            System.out.println("Number is not palindrome");
        }
    }
}
