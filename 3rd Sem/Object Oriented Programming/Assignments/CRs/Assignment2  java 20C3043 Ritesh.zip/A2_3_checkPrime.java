public class A2_3_checkPrime{
    public static void main(String[] args) {
        int n=61;
       int a=n/2;
        int p=0;
        for(int i=1;i<=a;i++){
            if(n%i==0){
                p++;
            }
        }
        if(p==1){
            System.out.println("Yes! This is a prime number");
        }
        else{
            System.out.println("No! This is not a prime number");
        }
    }
}
