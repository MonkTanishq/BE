public class A2_4_checkArmstrong{
    public static void main(String[] args) {
        int n=153;
        int a=n;
        int p=0;
        int sum=1;
        int result=0;
        while(n!=0){
           int m=n%10;
            p++;
            n=n/10;
        }
        n=a;
        while (n!=0){
            int m=n%10;
            for(int i=1;i<=p;i++){
                sum=sum*m;
            }
            result=result+sum;
            sum=1;
            n=n/10;
        }
        if(a==result){
            System.out.println("Yes! This is Armstrong number");
        }
        else{
            System.out.println("No! This is not a Armstrong number");
        }
    }
}
