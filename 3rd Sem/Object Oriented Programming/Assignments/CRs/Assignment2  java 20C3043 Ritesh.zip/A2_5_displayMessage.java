import java.util.*;
public class A2_5_displayMessage{
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.print("Marks: ");
        int a= sc.nextInt();
        if(a>90 && a<=100){
            System.out.println("Awesome");
        }
        else if(a<=90 && a>85){
            System.out.println("Great");
        }
        else if(a<=85 && a>70){
            System.out.println("Good");
        }
        else if(a<=70 && a>65){
            System.out.println("Ok");
        }
        else if(a<=65 && a>45){
            System.out.println("Try to do better next time");
        }
        else if(a<=45 && a>0){
            System.out.println("You need more practice");
        }
        else{
            System.out.println("Try again");
        }
    }
}
