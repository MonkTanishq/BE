import java.util.Scanner;

public class A2_6_printInteger{
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter a number: ");
        float n = sc.nextFloat();
        int x =(int) n;
        System.out.println("Given number is: "+n);
        System.out.println("Largest integer not greater than number is: "+x);
        System.out.println("Small integer not less than number is: "+(x+1));
    }
}
