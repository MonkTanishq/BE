public class A2_7_sortNumericStringArray{
    public static void main(String[] args) {
        int arr1[]={3,6,5,2,8,9};
        String arr2[]={"a","x","z","b","y","c"};
        //for loop to sort numeric array
        for(int i=0;i<arr1.length-1;i++){
            for(int j=i+1;j<arr1.length;j++){
                if(arr1[j]<arr1[i]){
                    int temp=arr1[i];
                    arr1[i]=arr1[j];
                    arr1[j]=temp;
                }
            }
        }
        //print sorted numeric array
        System.out.println("Sorted numeric array");
        for(int i=0;i<arr1.length;i++){
            System.out.print(arr1[i]+" ");
        }
        System.out.println();
       //for loop to sort string array
        for(int i=0;i<arr2.length-1;i++){
            for(int j=i+1;j<arr2.length;j++){
                if(arr2[j].compareTo(arr2[i])<0){
                    String temp=arr2[i];
                    arr2[i]=arr2[j];
                    arr2[j]=temp;
                }
            }
        }
        System.out.println("Sorted string array");
        for(int i=0;i<arr2.length;i++){
            System.out.print(arr2[i]+",");
        }
    }
}
