import java.util.*;
public class A2_9_commonElements{
    public static void main(String[] args){
        //find the common elements in two arrays
        Scanner sc=new Scanner(System.in);
        int []arr1={12,3,45,4,6};
        int []arr2={12,9,4,6,2};
        System.out.println("Common elements are: ");
        for(int i=0;i<5;i++){
           for(int j=0;j<5;j++){
               if(arr1[i]==arr2[j]){
                   System.out.print(arr1[i]+" ");
               }
           }
        }
    }
}
