import java.util.Scanner;

public class A3_10_increasingDecreasing{
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int p,q,r;
        System.out.println("Enter Numbers: ");
        p=sc.nextInt();
        q=sc.nextInt();
        r=sc.nextInt();
        if(p<q&&q<r){
            System.out.println("Increasing");
        }
        else if(r<q&&q<p){
            System.out.println("Decreasing");
        }
        else{
            System.out.println("Neither increasing or decreasing");
        }
    }
}
