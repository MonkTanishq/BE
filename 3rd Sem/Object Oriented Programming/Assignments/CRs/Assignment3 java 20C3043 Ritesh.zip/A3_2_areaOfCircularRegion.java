import java.util.Scanner;

public class A3_2_areaOfCircularRegion{
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter the radius of inner circle: ");
        int radius1=sc.nextInt();
        System.out.print("Enter the radius of outer circle: ");
        int radius2=sc.nextInt();
       if(radius2>radius1){
           double result=Math.PI*radius2*radius2-Math.PI*radius1*radius1;
           System.out.println("Area of circular region: "+ result);
       }
       else{
           System.out.println("Check tha radius Again!");
       }

    }
}
