public class A3_3_findVowels{
    public static void main(String[] args) {
        int t=0;
        String n="Ritesh";
        for(int i=0;i<n.length();i++){
            String temp="AEIOUaeiou";
            for(int j=0;j<temp.length();j++){
                if(n.charAt(i)==temp.charAt(j)){
                    t++;
                }
            }
        }
        System.out.println("No of vowel in string is: "+t);
    }
}
