import java.util.Scanner;

public class A3_5_sortingArrays{
    public static void main(String[] args) {
       Scanner sc=new Scanner(System.in);
        System.out.println("Enter\n1 for Bubble Sort\n"+"2 for Insertion Sort\n"+"3 for Selection Sort");
        int n=sc.nextInt();
        int arr[]={3,8,6,9,1,5,4,7};
        switch(n){
            case 1:
                System.out.println("Sorted array by Bubble sort is");
                int counter=1;
                while(counter<arr.length){
                    for(int i=0;i<arr.length-counter;i++){
                        if(arr[i]>arr[i+1]){
                            int temp=arr[i];
                            arr[i]=arr[i+1];
                            arr[i+1]=temp;
                        }
                    }
                    counter++;
                }
                for(int i=0;i<arr.length;i++){
                    System.out.print(arr[i]+" ");
                }
                break;
            case 2:
                System.out.println("Sorted array by Insertion sort is");
                for(int i=1;i<arr.length;i++){
                    int current=arr[i];
                    int j=i-1;
                    while(j>=0 && arr[j]>current){
                        arr[j+1]=arr[j];
                        j--;
                    }
                    arr[j+1]=current;
                }
                for(int i=0;i<arr.length;i++){
                    System.out.print(arr[i]+" ");
                }
                break;
            case 3:
                System.out.println("Sorted array by Selection sort is");
                for(int i=0;i<arr.length-1;i++){
                    for(int j=i+1;j<arr.length;j++){
                        if(arr[j]<arr[i]){
                            int temp=arr[j];
                            arr[j]=arr[i];
                            arr[i]=temp;
                        }
                    }
                }
                  for(int i=0;i<arr.length;i++){
                    System.out.print(arr[i]+" ");
                  }
                break;
            default:
                System.out.println("Try again!!");
        }
    }
}
