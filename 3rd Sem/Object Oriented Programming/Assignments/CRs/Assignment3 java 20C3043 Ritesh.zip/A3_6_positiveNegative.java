import java.util.Scanner;

public class A3_6_positiveNegative{
    public static void main(String[] args) {
        //write a code to print whether a number is positive or negative
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter a number: ");
        int n=sc.nextInt();
        if(n<0){
            System.out.println("Number is negative");
        }
        else{
            System.out.println("Number is positive");
        }
    }
}
