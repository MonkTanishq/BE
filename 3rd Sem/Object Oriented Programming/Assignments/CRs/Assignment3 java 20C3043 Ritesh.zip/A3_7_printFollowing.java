import java.util.Scanner;

public class A3_7_printFollowing{
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter a number: ");
        float n=sc.nextFloat();
        float p=Math.abs(n);
        if(n==0){
            System.out.println("Zero");
        }
        else if(n>0){
            System.out.println("Positive");
        }
        else{
            System.out.println("Negative");
        }
        if(p<1){
            System.out.println("Small");
        }
        else if(p>1000000){
            System.out.println("Large");
        }
    }
}
