import java.util.Scanner;

public class A3_9_displayCube{
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter a number: ");
        int n=sc.nextInt();
        //display cube of number up to a given integer which is taken by user
        for(int i=1;i<=n;i++){
            System.out.print(i*i*i+" ");
        }
    }
}
