arr = [5, 4, 3, 2, 1]

first_element = arr[0]
last_element = arr[len(arr) - 1]
if first_element < last_element:
    print("List is sorted in ascending order")
else:
    print("List is sorted in descending order")


