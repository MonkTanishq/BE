arr = [1, 2, 3, 4, 5, 6]

for num in arr:
    if num % 2 == 0:
        print(f"{num} is even number")
